This project exists so the cmake build steps in uberenv-conduit can execute
a cmake build of *something* and not fail early before the conduit host
config has been created as part of the spack build/install process.
